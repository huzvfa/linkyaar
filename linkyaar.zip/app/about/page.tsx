import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Heart, Target, Users } from "lucide-react";

export default function About() {
  return (
    <main style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Navbar />
      <section style={{ padding: "80px 24px", textAlign: "center" }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          <h1 style={{ fontSize: 52, fontWeight: 800, marginBottom: 20 }}>Pakistan ke Creators ka Ghar 🇵🇰</h1>
          <p style={{ color: "var(--muted)", fontSize: 18, lineHeight: 1.8 }}>LinkYaar ka ek hi mission hai — Pakistan ke talented creators ko brands se connect karna, taake dono grow kar sakein.</p>
        </div>
      </section>
      <section style={{ padding: "0 24px 80px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 28 }}>
          {[
            { icon: Heart, title: "Hamara Mission", desc: "Pakistan mein creator economy ko grow karna. Har creator ko uski mehnat ka sahi daam milna chahiye." },
            { icon: Target, title: "Hamara Vision", desc: "Pakistan ka sabse bada aur trusted UGC marketplace banana — jahan 10 lakh creators ho." },
            { icon: Users, title: "Hamari Team", desc: "Rawalpindi se shuru hua ek chhota sa team jo Pakistan ki digital economy mein revolution lana chahta hai." },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} style={{ background: "var(--card)", borderRadius: 16, padding: 32, border: "1px solid var(--border)", textAlign: "center" }}>
              <div style={{ width: 56, height: 56, borderRadius: 14, background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
                <Icon size={24} color="var(--accent)" />
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>{title}</h3>
              <p style={{ color: "var(--muted)", fontSize: 15, lineHeight: 1.7 }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>
      <Footer />
    </main>
  );
}
