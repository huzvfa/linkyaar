import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Search, Filter } from "lucide-react";

const creators = [
  { name: "Ayesha Malik", niche: "Fashion & Lifestyle", city: "Lahore", followers: "245K", rate: "PKR 15,000", platforms: ["Instagram", "TikTok"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=ayesha&backgroundColor=b6e3f4", rating: 4.9, reviews: 34 },
  { name: "Bilal Ahmed", niche: "Food & Travel", city: "Karachi", followers: "89K", rate: "PKR 8,000", platforms: ["Instagram", "YouTube"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=bilal&backgroundColor=ffdfbf", rating: 4.7, reviews: 21 },
  { name: "Sara Khan", niche: "Beauty & Skincare", city: "Islamabad", followers: "312K", rate: "PKR 20,000", platforms: ["TikTok", "Instagram"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=sara&backgroundColor=c0aede", rating: 5.0, reviews: 56 },
  { name: "Usman Riaz", niche: "Tech & Gaming", city: "Rawalpindi", followers: "156K", rate: "PKR 12,000", platforms: ["YouTube", "Instagram"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=usman&backgroundColor=d1d4f9", rating: 4.8, reviews: 18 },
  { name: "Fatima Noor", niche: "Fitness & Health", city: "Lahore", followers: "78K", rate: "PKR 7,000", platforms: ["Instagram", "TikTok"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=fatima&backgroundColor=ffd5dc", rating: 4.6, reviews: 12 },
  { name: "Hassan Zafar", niche: "Comedy & Entertainment", city: "Karachi", followers: "520K", rate: "PKR 35,000", platforms: ["TikTok", "YouTube"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=hassan&backgroundColor=d4edda", rating: 4.9, reviews: 72 },
  { name: "Zara Sheikh", niche: "Home & Decor", city: "Islamabad", followers: "43K", rate: "PKR 5,000", platforms: ["Instagram"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=zara&backgroundColor=fff3cd", rating: 4.5, reviews: 9 },
  { name: "Ali Raza", niche: "Automobiles", city: "Rawalpindi", followers: "95K", rate: "PKR 10,000", platforms: ["YouTube", "Instagram"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=aliraza&backgroundColor=cce5ff", rating: 4.7, reviews: 27 },
];

const niches = ["All", "Fashion", "Food", "Beauty", "Tech", "Fitness", "Comedy", "Home", "Automobiles"];

export default function Creators() {
  return (
    <main style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Navbar />
      <section style={{ padding: "60px 24px 40px", background: "var(--surface)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <h1 style={{ fontSize: 48, fontWeight: 800, marginBottom: 8 }}>Browse Creators</h1>
          <p style={{ color: "var(--muted)", fontSize: 17, marginBottom: 32 }}>Pakistan ke 2,400+ verified content creators</p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 280, display: "flex", alignItems: "center", gap: 12, background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: "12px 18px" }}>
              <Search size={18} color="var(--muted)" />
              <span style={{ color: "var(--muted)", fontSize: 15 }}>Creator ya niche search karo...</span>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {niches.map(n => (
                <button key={n} style={{ background: n === "All" ? "var(--accent)" : "var(--card)", color: n === "All" ? "#fff" : "var(--muted)", border: "1px solid var(--border)", borderRadius: 8, padding: "10px 16px", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>{n}</button>
              ))}
            </div>
          </div>
        </div>
      </section>
      <section style={{ padding: "48px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: 24 }}>
            {creators.map(c => (
              <div key={c.name} style={{ background: "var(--card)", borderRadius: 16, overflow: "hidden", border: "1px solid var(--border)" }}>
                <div style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(245,158,11,0.1))", padding: "28px 24px 16px", textAlign: "center" }}>
                  <img src={c.img} alt={c.name} style={{ width: 84, height: 84, borderRadius: "50%", border: "3px solid var(--accent)", marginBottom: 12 }} />
                  <h3 style={{ fontSize: 17, fontWeight: 700, marginBottom: 4 }}>{c.name}</h3>
                  <p style={{ color: "var(--accent2)", fontSize: 13, fontWeight: 600 }}>{c.niche}</p>
                  <p style={{ color: "var(--muted)", fontSize: 12, marginTop: 4 }}>⭐ {c.rating} ({c.reviews} reviews)</p>
                </div>
                <div style={{ padding: "16px 20px 20px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                    <span style={{ color: "var(--muted)", fontSize: 13 }}>📍 {c.city}</span>
                    <span style={{ color: "var(--muted)", fontSize: 13 }}>👥 {c.followers}</span>
                  </div>
                  <div style={{ display: "flex", gap: 5, marginBottom: 14, flexWrap: "wrap" }}>
                    {c.platforms.map(p => (<span key={p} style={{ background: "rgba(124,58,237,0.15)", color: "var(--accent)", fontSize: 11, fontWeight: 600, padding: "3px 8px", borderRadius: 4 }}>{p}</span>))}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: 11, color: "var(--muted)" }}>Starting from</div>
                      <div style={{ fontWeight: 700, fontSize: 15 }}>{c.rate}</div>
                    </div>
                    <Link href="/signup" style={{ background: "var(--accent)", color: "#fff", textDecoration: "none", padding: "8px 16px", borderRadius: 8, fontSize: 13, fontWeight: 600 }}>Hire Now</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
