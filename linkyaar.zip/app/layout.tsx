import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LinkYaar — Link with Creators",
  description: "Pakistan's #1 UGC marketplace. Connect brands with top content creators.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="grain" />
        {children}
      </body>
    </html>
  );
}
