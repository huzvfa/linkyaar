import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowRight, Users, TrendingUp, Shield } from "lucide-react";

const creators = [
  { name: "Ayesha Malik", niche: "Fashion & Lifestyle", city: "Lahore", followers: "245K", rate: "PKR 15,000", platforms: ["Instagram", "TikTok"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=ayesha&backgroundColor=b6e3f4" },
  { name: "Bilal Ahmed", niche: "Food & Travel", city: "Karachi", followers: "89K", rate: "PKR 8,000", platforms: ["Instagram", "YouTube"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=bilal&backgroundColor=ffdfbf" },
  { name: "Sara Khan", niche: "Beauty & Skincare", city: "Islamabad", followers: "312K", rate: "PKR 20,000", platforms: ["TikTok", "Instagram"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=sara&backgroundColor=c0aede" },
  { name: "Usman Riaz", niche: "Tech & Gaming", city: "Rawalpindi", followers: "156K", rate: "PKR 12,000", platforms: ["YouTube", "Instagram"], img: "https://api.dicebear.com/7.x/avataaars/svg?seed=usman&backgroundColor=d1d4f9" },
];

const stats = [
  { value: "2,400+", label: "Registered Creators" },
  { value: "380+", label: "Brands Onboarded" },
  { value: "12,000+", label: "Campaigns Completed" },
  { value: "PKR 4.2Cr", label: "Paid to Creators" },
];

export default function Home() {
  return (
    <main style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Navbar />
      <section style={{ position: "relative", overflow: "hidden", padding: "100px 24px 120px" }}>
        <div style={{ position: "absolute", top: "10%", left: "50%", transform: "translateX(-50%)", width: 600, height: 600, background: "radial-gradient(circle, rgba(124,58,237,0.15) 0%, transparent 70%)", borderRadius: "50%", pointerEvents: "none" }} />
        <div style={{ maxWidth: 900, margin: "0 auto", textAlign: "center", position: "relative" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.4)", borderRadius: 100, padding: "6px 16px", marginBottom: 32 }}>
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent2)" }} />
            <span style={{ fontSize: 13, color: "var(--accent2)", fontWeight: 600 }}>Pakistan's #1 Creator Marketplace</span>
          </div>
          <h1 style={{ fontSize: "clamp(42px, 7vw, 76px)", fontWeight: 800, lineHeight: 1.08, marginBottom: 24, letterSpacing: "-2px" }}>
            Brands aur Creators<br />
            <span style={{ background: "linear-gradient(135deg, #7c3aed, #f59e0b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Ek Jagah. ✨</span>
          </h1>
          <p style={{ fontSize: 19, color: "var(--muted)", maxWidth: 580, margin: "0 auto 44px", lineHeight: 1.7 }}>Hire Pakistan's top UGC creators for your brand campaigns. Real content. Real results. Seedha apne phone se.</p>
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/creators" style={{ background: "var(--accent)", color: "#fff", textDecoration: "none", padding: "14px 32px", borderRadius: 12, fontSize: 16, fontWeight: 700, display: "flex", alignItems: "center", gap: 8, boxShadow: "0 0 30px rgba(124,58,237,0.4)" }}>Browse Creators <ArrowRight size={18} /></Link>
            <Link href="/signup" style={{ background: "var(--card)", color: "var(--text)", textDecoration: "none", padding: "14px 32px", borderRadius: 12, fontSize: 16, fontWeight: 700, border: "1px solid var(--border)" }}>Join as Creator</Link>
          </div>
          <div style={{ display: "flex", gap: 40, justifyContent: "center", marginTop: 60, flexWrap: "wrap" }}>
            {stats.map(s => (
              <div key={s.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 28, fontWeight: 800, fontFamily: "Syne, sans-serif" }}>{s.value}</div>
                <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "80px 24px", background: "var(--surface)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 64 }}>
            <h2 style={{ fontSize: 42, fontWeight: 800, marginBottom: 16 }}>Kaam kaise karta hai?</h2>
            <p style={{ color: "var(--muted)", fontSize: 17 }}>3 simple steps mein apna campaign shuru karo</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 32 }}>
            {[
              { step: "01", icon: Users, title: "Brand Sign Up Karo", desc: "Apna brand register karo aur campaign brief bharo. Sirf 5 minutes lagte hain." },
              { step: "02", icon: TrendingUp, title: "Creator Dhundo", desc: "Thousands of verified Pakistani creators browse karo — niche, city, aur budget ke hisaab se filter karo." },
              { step: "03", icon: Shield, title: "Content Receive Karo", desc: "Creator se directly baat karo, payment securely karo, aur apna content receive karo." },
            ].map(({ step, icon: Icon, title, desc }) => (
              <div key={step} style={{ background: "var(--card)", borderRadius: 16, padding: 32, border: "1px solid var(--border)", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 16, right: 20, fontSize: 64, fontWeight: 900, color: "rgba(124,58,237,0.08)", fontFamily: "Syne, sans-serif" }}>{step}</div>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 20 }}>
                  <Icon size={22} color="var(--accent)" />
                </div>
                <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 10 }}>{title}</h3>
                <p style={{ color: "var(--muted)", fontSize: 15, lineHeight: 1.7 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "80px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 48 }}>
            <div>
              <h2 style={{ fontSize: 42, fontWeight: 800, marginBottom: 8 }}>Featured Creators</h2>
              <p style={{ color: "var(--muted)", fontSize: 16 }}>Pakistan ke top verified creators</p>
            </div>
            <Link href="/creators" style={{ color: "var(--accent)", textDecoration: "none", fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>Sab dekho <ArrowRight size={16} /></Link>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24 }}>
            {creators.map(c => (
              <div key={c.name} style={{ background: "var(--card)", borderRadius: 16, overflow: "hidden", border: "1px solid var(--border)" }}>
                <div style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(245,158,11,0.1))", padding: "24px 24px 16px", textAlign: "center" }}>
                  <img src={c.img} alt={c.name} style={{ width: 80, height: 80, borderRadius: "50%", border: "3px solid var(--accent)", marginBottom: 12 }} />
                  <h3 style={{ fontSize: 17, fontWeight: 700, marginBottom: 4 }}>{c.name}</h3>
                  <p style={{ color: "var(--accent2)", fontSize: 13, fontWeight: 600 }}>{c.niche}</p>
                </div>
                <div style={{ padding: "16px 24px 24px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                    <span style={{ color: "var(--muted)", fontSize: 13 }}>📍 {c.city}</span>
                    <span style={{ color: "var(--muted)", fontSize: 13 }}>👥 {c.followers}</span>
                  </div>
                  <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
                    {c.platforms.map(p => (<span key={p} style={{ background: "rgba(124,58,237,0.15)", color: "var(--accent)", fontSize: 11, fontWeight: 600, padding: "3px 8px", borderRadius: 4 }}>{p}</span>))}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontWeight: 700, fontSize: 15 }}>{c.rate}</span>
                    <Link href="/creators" style={{ background: "var(--accent)", color: "#fff", textDecoration: "none", padding: "7px 14px", borderRadius: 8, fontSize: 13, fontWeight: 600 }}>Hire</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "80px 24px" }}>
        <div style={{ maxWidth: 800, margin: "0 auto", textAlign: "center", background: "linear-gradient(135deg, rgba(124,58,237,0.2), rgba(245,158,11,0.1))", borderRadius: 24, padding: "64px 48px", border: "1px solid rgba(124,58,237,0.3)" }}>
          <h2 style={{ fontSize: 44, fontWeight: 800, marginBottom: 16 }}>Aaj shuru karo 🚀</h2>
          <p style={{ color: "var(--muted)", fontSize: 18, marginBottom: 36 }}>Free register karo. No credit card needed.</p>
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/signup" style={{ background: "var(--accent)", color: "#fff", textDecoration: "none", padding: "14px 32px", borderRadius: 12, fontSize: 16, fontWeight: 700 }}>Brand ke liye Sign Up</Link>
            <Link href="/signup" style={{ background: "var(--card)", color: "var(--text)", textDecoration: "none", padding: "14px 32px", borderRadius: 12, fontSize: 16, fontWeight: 700, border: "1px solid var(--border)" }}>Creator ke liye Sign Up</Link>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
