import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Basic",
    price: "PKR 5,000",
    period: "/month",
    desc: "Choti brands ke liye perfect",
    color: "var(--border)",
    features: ["5 creator contacts/month", "Campaign brief posting", "Basic creator profiles", "JazzCash/EasyPaisa payments", "Email support"],
    cta: "Start Free Trial",
    popular: false,
  },
  {
    name: "Pro",
    price: "PKR 15,000",
    period: "/month",
    desc: "Growing brands ke liye",
    color: "var(--accent)",
    features: ["Unlimited creator contacts", "Priority campaign matching", "Full creator analytics", "Dedicated account manager", "WhatsApp support", "Campaign tracking dashboard", "15% commission only on deals"],
    cta: "Get Pro",
    popular: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "Large brands & agencies",
    color: "var(--accent2)",
    features: ["Everything in Pro", "Custom contract terms", "White-label options", "Bulk campaign management", "API access", "24/7 dedicated support", "Custom reporting"],
    cta: "Contact Us",
    popular: false,
  },
];

export default function Pricing() {
  return (
    <main style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Navbar />
      <section style={{ padding: "80px 24px 48px", textAlign: "center" }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          <h1 style={{ fontSize: 52, fontWeight: 800, marginBottom: 16 }}>Simple Pricing 💸</h1>
          <p style={{ color: "var(--muted)", fontSize: 18, lineHeight: 1.7 }}>Koi hidden charges nahi. Sirf results ke liye pay karo.</p>
        </div>
      </section>
      <section style={{ padding: "0 24px 80px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 28 }}>
          {plans.map(p => (
            <div key={p.name} style={{ background: "var(--card)", borderRadius: 20, padding: 36, border: `1px solid ${p.popular ? "var(--accent)" : "var(--border)"}`, position: "relative", boxShadow: p.popular ? "0 0 40px rgba(124,58,237,0.2)" : "none" }}>
              {p.popular && <div style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: "var(--accent)", color: "#fff", fontSize: 12, fontWeight: 700, padding: "4px 16px", borderRadius: 100 }}>MOST POPULAR</div>}
              <h3 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>{p.name}</h3>
              <p style={{ color: "var(--muted)", fontSize: 14, marginBottom: 20 }}>{p.desc}</p>
              <div style={{ marginBottom: 28 }}>
                <span style={{ fontSize: 40, fontWeight: 800, fontFamily: "Syne, sans-serif" }}>{p.price}</span>
                <span style={{ color: "var(--muted)", fontSize: 15 }}>{p.period}</span>
              </div>
              <Link href="/signup" style={{ display: "block", textAlign: "center", background: p.popular ? "var(--accent)" : "var(--surface)", color: "#fff", textDecoration: "none", padding: "13px 24px", borderRadius: 10, fontSize: 15, fontWeight: 700, marginBottom: 28, border: `1px solid ${p.popular ? "var(--accent)" : "var(--border)"}` }}>{p.cta}</Link>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {p.features.map(f => (
                  <div key={f} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 20, height: 20, borderRadius: "50%", background: "rgba(124,58,237,0.2)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <Check size={12} color="var(--accent)" />
                    </div>
                    <span style={{ color: "var(--muted)", fontSize: 14 }}>{f}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
      <Footer />
    </main>
  );
}
