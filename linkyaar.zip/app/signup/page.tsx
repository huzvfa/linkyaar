import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Briefcase, Camera } from "lucide-react";
import Link from "next/link";

export default function Signup() {
  return (
    <main style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Navbar />
      <section style={{ padding: "80px 24px" }}>
        <div style={{ maxWidth: 800, margin: "0 auto", textAlign: "center" }}>
          <h1 style={{ fontSize: 48, fontWeight: 800, marginBottom: 16 }}>Join LinkYaar 🎉</h1>
          <p style={{ color: "var(--muted)", fontSize: 18, marginBottom: 52 }}>Aap kaunse hain — Brand ya Creator?</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            <div style={{ background: "var(--card)", borderRadius: 20, padding: 40, border: "1px solid var(--border)", cursor: "pointer", transition: "border-color 0.2s" }}>
              <div style={{ width: 64, height: 64, borderRadius: 16, background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px" }}>
                <Briefcase size={28} color="var(--accent)" />
              </div>
              <h2 style={{ fontSize: 24, fontWeight: 800, marginBottom: 12 }}>Main Brand hun 🏢</h2>
              <p style={{ color: "var(--muted)", fontSize: 15, lineHeight: 1.7, marginBottom: 28 }}>Mujhe apne brand ke liye UGC creators hire karne hain aur campaigns chalane hain.</p>
              <div style={{ background: "var(--accent)", color: "#fff", padding: "13px 24px", borderRadius: 10, fontSize: 15, fontWeight: 700 }}>Brand ke liye Sign Up</div>
            </div>
            <div style={{ background: "var(--card)", borderRadius: 20, padding: 40, border: "1px solid var(--border)", cursor: "pointer" }}>
              <div style={{ width: 64, height: 64, borderRadius: 16, background: "rgba(245,158,11,0.15)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px" }}>
                <Camera size={28} color="var(--accent2)" />
              </div>
              <h2 style={{ fontSize: 24, fontWeight: 800, marginBottom: 12 }}>Main Creator hun 📸</h2>
              <p style={{ color: "var(--muted)", fontSize: 15, lineHeight: 1.7, marginBottom: 28 }}>Main apna content sell karna chahta/chahti hun aur brands ke saath kaam karna chahta/chahti hun.</p>
              <div style={{ background: "var(--accent2)", color: "#000", padding: "13px 24px", borderRadius: 10, fontSize: 15, fontWeight: 700 }}>Creator ke liye Sign Up</div>
            </div>
          </div>
          <p style={{ color: "var(--muted)", fontSize: 14, marginTop: 32 }}>Already account hai? <Link href="/" style={{ color: "var(--accent)", textDecoration: "none", fontWeight: 600 }}>Login karo</Link></p>
        </div>
      </section>
      <Footer />
    </main>
  );
}
