import { Zap } from "lucide-react";

export default function Footer() {
  return (
    <footer style={{ borderTop: "1px solid var(--border)", background: "var(--surface)", padding: "60px 24px 32px" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 48, marginBottom: 48 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
              <div style={{ background: "var(--accent)", borderRadius: 8, padding: "4px 10px", display: "flex", alignItems: "center", gap: 6 }}>
                <Zap size={14} color="#fff" fill="#fff" />
                <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, color: "#fff", fontSize: 15 }}>LinkYaar</span>
              </div>
            </div>
            <p style={{ color: "var(--muted)", fontSize: 14, lineHeight: 1.7, maxWidth: 280 }}>Pakistan ka #1 UGC marketplace. Brands aur creators ko connect karo.</p>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              {["📸 Instagram", "🎵 TikTok"].map(s => (
                <div key={s} style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8, padding: "6px 12px", fontSize: 12, color: "var(--muted)", cursor: "pointer" }}>{s}</div>
              ))}
            </div>
          </div>
          {[
            { title: "Platform", links: ["Browse Creators", "For Brands", "Pricing", "How it Works"] },
            { title: "Company", links: ["About", "Blog", "Careers", "Contact"] },
            { title: "Legal", links: ["Privacy Policy", "Terms of Service", "Cookie Policy"] },
          ].map(col => (
            <div key={col.title}>
              <h4 style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16, color: "var(--text)" }}>{col.title}</h4>
              {col.links.map(link => (
                <div key={link} style={{ marginBottom: 10 }}>
                  <span style={{ color: "var(--muted)", fontSize: 14, cursor: "pointer" }}>{link}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
        <div style={{ borderTop: "1px solid var(--border)", paddingTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <p style={{ color: "var(--muted)", fontSize: 13 }}>© 2025 LinkYaar. Made with ❤️ in Pakistan.</p>
          <p style={{ color: "var(--muted)", fontSize: 13 }}>🇵🇰 Rawalpindi, Pakistan</p>
        </div>
      </div>
    </footer>
  );
}
