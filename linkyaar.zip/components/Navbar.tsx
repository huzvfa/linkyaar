"use client";
import { useState } from "react";
import Link from "next/link";
import { Zap } from "lucide-react";

export default function Navbar() {
  return (
    <nav style={{ background: 'rgba(10,10,15,0.85)', backdropFilter: 'blur(20px)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 100 }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none' }}>
          <div style={{ background: 'var(--accent)', borderRadius: 8, padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Zap size={16} color="#fff" fill="#fff" />
            <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, color: '#fff', fontSize: 17 }}>LinkYaar</span>
          </div>
        </Link>
        <div style={{ display: 'flex', gap: 32, alignItems: 'center' }}>
          {[['Creators', '/creators'], ['Brands', '/brands'], ['Pricing', '/pricing'], ['About', '/about']].map(([item, href]) => (
            <Link key={item} href={href} style={{ color: 'var(--muted)', textDecoration: 'none', fontSize: 15, fontWeight: 500 }}>{item}</Link>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <Link href="/signup" style={{ background: 'var(--accent)', color: '#fff', textDecoration: 'none', padding: '9px 22px', borderRadius: 8, fontSize: 14, fontWeight: 600 }}>Get Started</Link>
        </div>
      </div>
    </nav>
  );
}
